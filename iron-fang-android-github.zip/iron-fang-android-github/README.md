# IRON FANG: Shattered Crown — Android APK (GitHub Actions)

## طريقة استخراج ملف الـ APK مجاناً من GitHub (في دقيقتين)

1. فك الضغط عن الملف المضغوط.
2. اعمل Repository جديد على حسابك في GitHub وارفع كل الملفات اللي جوه الفولدر (بما فيها فولدر `.github` وفولدر `www`).
3. افتح تبويب **Actions** في الـ Repository على GitHub، هتلاقي عملية **Build Android APK** شغالة أوتوماتيكياً (ولو ما بدأتش دوس **Run workflow**).
4. بعد دقيقتين تقريباً، لما تخلص وتظهر علامة صح خضراء، افتحها وانزل تحت عند **Artifacts** وحمّل **IronFang-Android-APK**.
5. فك الضغط هتلاقي ملف `app-debug.apk` — ابعته لموبايلك وثبّته واستمتع باللعبة بشاشة كاملة بالعرض!

---

## Local Build (Optional)
```bash
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
The APK will be generated at `android/app/build/outputs/apk/debug/app-debug.apk`.
