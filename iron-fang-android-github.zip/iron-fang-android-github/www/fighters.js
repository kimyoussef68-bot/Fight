// fighters.js - Playable roster definitions, stats, palettes, and special/super move metadata
(function (IF) {
  'use strict';

  const FIGHTERS = [
    {
      id: 'ryuken',
      name: 'KAIRO',
      title: 'Crimson Dragon',
      origin: 'Kyoto, Japan',
      style: 'Shotokan Flame-Do',
      bio: 'Balanced wandering martial artist wielding disciplined strikes and blazing chi blasts.',
      stats: { power: 82, speed: 80, defense: 80, range: 78 },
      maxHp: 1000,
      walkSpeed: 290,
      backSpeed: 235,
      runSpeed: 490,
      jumpVel: -760,
      doubleJumpVel: -670,
      gravity: 1950,
      specialName: 'HADOU BLAZE',
      specialType: 'projectile',
      superName: 'INFERNO SHORYU',
      superType: 'dragon_beam',
      colors: {
        skin: '#f0c4a0',
        skinShadow: '#c78c68',
        hair: '#1c1926',
        gi: '#f2f4f8',
        giShadow: '#b8c2d6',
        accent: '#e62e3d',
        accentGlow: '#ff6b4a',
        belt: '#1f2330',
        boots: '#242938',
        aura: '#ff4d2e'
      },
      outfit: 'karate_gi'
    },
    {
      id: 'kurogane',
      name: 'VEXA',
      title: 'Neon Phantom',
      origin: 'Neo-Shibuya',
      style: 'Cyber Kunoichi',
      bio: 'Blindingly fast shadow assassin with lethal kick combos, double-jump agility, and plasma dashes.',
      stats: { power: 74, speed: 96, defense: 70, range: 82 },
      maxHp: 940,
      walkSpeed: 345,
      backSpeed: 280,
      runSpeed: 560,
      jumpVel: -810,
      doubleJumpVel: -720,
      gravity: 1900,
      specialName: 'PHANTOM BLITZ',
      specialType: 'dash_strike',
      superName: 'CYBER TEMPEST',
      superType: 'flurry_surge',
      colors: {
        skin: '#f3cfb8',
        skinShadow: '#c9997d',
        hair: '#1de9f6',
        gi: '#1b1d2e',
        giShadow: '#0d0f1a',
        accent: '#00f0ff',
        accentGlow: '#ff2bd6',
        belt: '#ff2bd6',
        boots: '#111422',
        aura: '#00f0ff'
      },
      outfit: 'cyber_ninja'
    },
    {
      id: 'titan',
      name: 'BROG',
      title: 'Iron Colossus',
      origin: 'Volga Foundry',
      style: 'Heavy Pankration',
      bio: 'Armored powerhouse whose seismic slams and armored uppercuts shatter guards and launch foes.',
      stats: { power: 98, speed: 64, defense: 96, range: 86 },
      maxHp: 1140,
      walkSpeed: 240,
      backSpeed: 195,
      runSpeed: 420,
      jumpVel: -710,
      doubleJumpVel: -610,
      gravity: 2050,
      specialName: 'SEISMIC UPPER',
      specialType: 'rising_upper',
      superName: 'TITAN METEOR',
      superType: 'shockwave_slam',
      colors: {
        skin: '#d99e77',
        skinShadow: '#a66d4a',
        hair: '#3b2416',
        gi: '#404859',
        giShadow: '#232833',
        accent: '#f5a623',
        accentGlow: '#ffd452',
        belt: '#8a2323',
        boots: '#1b1f29',
        aura: '#ffaa00'
      },
      outfit: 'heavy_armor'
    },
    {
      id: 'amara',
      name: 'SORAIA',
      title: 'Desert Lightning',
      origin: 'Alexandria, Egypt',
      style: 'Tempest Capoeira',
      bio: 'Electrifying aerial striker combining sweeping crescent kicks with crackling arc bolts.',
      stats: { power: 84, speed: 88, defense: 78, range: 88 },
      maxHp: 980,
      walkSpeed: 315,
      backSpeed: 260,
      runSpeed: 525,
      jumpVel: -790,
      doubleJumpVel: -700,
      gravity: 1920,
      specialName: 'VOLT CRESCENT',
      specialType: 'projectile',
      superName: 'PHARAOH STORM',
      superType: 'dragon_beam',
      colors: {
        skin: '#c98e62',
        skinShadow: '#96613c',
        hair: '#18141f',
        gi: '#1f4e8c',
        giShadow: '#122f57',
        accent: '#ffd147',
        accentGlow: '#66f0ff',
        belt: '#ffd147',
        boots: '#1c2436',
        aura: '#ffe047'
      },
      outfit: 'royal_fighter'
    }
  ];

  IF.FIGHTERS = FIGHTERS;
  IF.getFighterById = function (id) {
    return FIGHTERS.find(f => f.id === id) || FIGHTERS[0];
  };
})(window.IronFang = window.IronFang || {});
