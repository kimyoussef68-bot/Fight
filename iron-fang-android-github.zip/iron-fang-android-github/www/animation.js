// animation.js - Articulated HD 2D procedural sprite animator, pose keyframe blender, and portrait renderer
(function (IF) {
  'use strict';

  // Articulated joint pose helper: coordinates relative to fighter hip center (0, 0)
  // Facing right (+X). Ground is at y = +94 (standing).
  const POSES = {
    idle: [
      { hipY: 0, torsoLean: 0.08, headTilt: 0, fShoulder: [10, -48], fElbow: [28, -28], fHand: [44, -44], bShoulder: [-12, -48], bElbow: [2, -26], bHand: [22, -38], fKnee: [20, 34], fFoot: [30, 88], bKnee: [-18, 36], bFoot: [-30, 88] },
      { hipY: 4, torsoLean: 0.11, headTilt: 0.04, fShoulder: [11, -46], fElbow: [30, -24], fHand: [46, -40], bShoulder: [-11, -46], bElbow: [4, -22], bHand: [24, -34], fKnee: [22, 36], fFoot: [30, 88], bKnee: [-20, 38], bFoot: [-30, 88] }
    ],
    walkF: [
      { hipY: 2, torsoLean: 0.16, headTilt: 0, fShoulder: [12, -48], fElbow: [30, -28], fHand: [44, -42], bShoulder: [-12, -48], bElbow: [-4, -26], bHand: [16, -36], fKnee: [32, 32], fFoot: [44, 86], bKnee: [-22, 38], bFoot: [-38, 86] },
      { hipY: -2, torsoLean: 0.14, headTilt: 0, fShoulder: [12, -48], fElbow: [24, -26], fHand: [38, -40], bShoulder: [-12, -48], bElbow: [8, -28], bHand: [26, -42], fKnee: [6, 36], fFoot: [10, 88], bKnee: [-4, 34], bFoot: [-12, 80] },
      { hipY: 2, torsoLean: 0.16, headTilt: 0, fShoulder: [12, -48], fElbow: [22, -28], fHand: [36, -42], bShoulder: [-12, -48], bElbow: [10, -26], bHand: [28, -38], fKnee: [-18, 38], fFoot: [-34, 86], bKnee: [30, 32], bFoot: [42, 86] }
    ],
    walkB: [
      { hipY: 3, torsoLean: -0.04, headTilt: 0, fShoulder: [10, -48], fElbow: [28, -30], fHand: [42, -46], bShoulder: [-12, -48], bElbow: [2, -28], bHand: [20, -42], fKnee: [26, 36], fFoot: [38, 88], bKnee: [-26, 34], bFoot: [-40, 86] },
      { hipY: 0, torsoLean: -0.02, headTilt: 0, fShoulder: [10, -48], fElbow: [24, -28], fHand: [40, -44], bShoulder: [-12, -48], bElbow: [0, -26], bHand: [18, -40], fKnee: [10, 34], fFoot: [12, 82], bKnee: [-8, 36], bFoot: [-14, 88] }
    ],
    run: [
      { hipY: 8, torsoLean: 0.34, headTilt: -0.1, fShoulder: [22, -42], fElbow: [42, -24], fHand: [56, -34], bShoulder: [-4, -44], bElbow: [-26, -24], bHand: [-40, -16], fKnee: [40, 26], fFoot: [54, 78], bKnee: [-32, 34], bFoot: [-56, 70] },
      { hipY: 2, torsoLean: 0.36, headTilt: -0.1, fShoulder: [22, -42], fElbow: [-14, -22], fHand: [-34, -18], bShoulder: [-4, -44], bElbow: [36, -22], bHand: [52, -34], fKnee: [-28, 36], fFoot: [-52, 74], bKnee: [42, 24], bFoot: [56, 78] }
    ],
    crouch: [
      { hipY: 36, torsoLean: 0.24, headTilt: -0.05, fShoulder: [16, -36], fElbow: [36, -16], fHand: [48, -28], bShoulder: [-10, -36], bElbow: [8, -16], bHand: [24, -26], fKnee: [36, 22], fFoot: [32, 54], bKnee: [-26, 26], bFoot: [-34, 54] }
    ],
    jump: [
      { hipY: -10, torsoLean: 0.14, headTilt: -0.06, fShoulder: [12, -48], fElbow: [34, -36], fHand: [46, -54], bShoulder: [-12, -48], bElbow: [-22, -34], bHand: [-10, -52], fKnee: [34, 18], fFoot: [22, 62], bKnee: [-18, 28], bFoot: [-34, 72] }
    ],
    doubleJump: [
      { hipY: -12, torsoLean: 0.35, headTilt: 0.1, fShoulder: [18, -42], fElbow: [36, -22], fHand: [24, -10], bShoulder: [-10, -42], bElbow: [-28, -24], bHand: [-18, -8], fKnee: [36, 10], fFoot: [16, 42], bKnee: [-20, 16], bFoot: [-30, 48] }
    ],
    block: [
      { hipY: 6, torsoLean: -0.08, headTilt: 0.08, fShoulder: [8, -46], fElbow: [26, -30], fHand: [32, -56], bShoulder: [-10, -46], bElbow: [18, -28], bHand: [24, -52], fKnee: [22, 34], fFoot: [28, 86], bKnee: [-22, 36], bFoot: [-36, 86] }
    ],
    lp: [
      { hipY: 1, torsoLean: 0.14, headTilt: 0, fShoulder: [12, -48], fElbow: [22, -30], fHand: [36, -46], bShoulder: [-12, -48], bElbow: [4, -30], bHand: [20, -42], fKnee: [22, 34], fFoot: [32, 88], bKnee: [-18, 36], bFoot: [-32, 88] },
      { hipY: 2, torsoLean: 0.24, headTilt: 0, fShoulder: [22, -46], fElbow: [56, -46], fHand: [90, -46], bShoulder: [-14, -46], bElbow: [-24, -26], bHand: [-10, -34], fKnee: [28, 34], fFoot: [38, 88], bKnee: [-22, 36], bFoot: [-38, 88] }
    ],
    hp: [
      { hipY: 5, torsoLean: -0.08, headTilt: 0, fShoulder: [4, -48], fElbow: [-18, -30], fHand: [-30, -38], bShoulder: [-14, -48], bElbow: [12, -32], bHand: [28, -46], fKnee: [22, 34], fFoot: [32, 88], bKnee: [-24, 36], bFoot: [-40, 88] },
      { hipY: 6, torsoLean: 0.36, headTilt: -0.05, fShoulder: [28, -42], fElbow: [68, -44], fHand: [108, -46], bShoulder: [-16, -44], bElbow: [-32, -24], bHand: [-44, -18], fKnee: [38, 32], fFoot: [48, 86], bKnee: [-26, 36], bFoot: [-48, 86] }
    ],
    lk: [
      { hipY: 0, torsoLean: -0.1, headTilt: 0, fShoulder: [6, -48], fElbow: [22, -28], fHand: [36, -42], bShoulder: [-14, -48], bElbow: [-26, -30], bHand: [-16, -44], fKnee: [34, 10], fFoot: [24, 52], bKnee: [-12, 38], bFoot: [-22, 88] },
      { hipY: -2, torsoLean: -0.22, headTilt: 0.05, fShoulder: [2, -48], fElbow: [18, -28], fHand: [32, -44], bShoulder: [-18, -46], bElbow: [-34, -26], bHand: [-42, -38], fKnee: [48, 6], fFoot: [94, -4], bKnee: [-14, 38], bFoot: [-24, 88] }
    ],
    hk: [
      { hipY: 2, torsoLean: -0.15, headTilt: 0, fShoulder: [4, -48], fElbow: [22, -28], fHand: [34, -42], bShoulder: [-14, -48], bElbow: [-28, -28], bHand: [-36, -38], fKnee: [30, -8], fFoot: [18, 32], bKnee: [-12, 38], bFoot: [-22, 88] },
      { hipY: -4, torsoLean: -0.34, headTilt: 0.1, fShoulder: [-4, -46], fElbow: [12, -26], fHand: [26, -40], bShoulder: [-22, -44], bElbow: [-42, -22], bHand: [-52, -32], fKnee: [54, -18], fFoot: [108, -42], bKnee: [-16, 38], bFoot: [-26, 88] }
    ],
    special: [
      { hipY: 8, torsoLean: -0.05, headTilt: 0, fShoulder: [2, -44], fElbow: [-16, -24], fHand: [-26, -28], bShoulder: [-14, -44], bElbow: [-22, -24], bHand: [-26, -28], fKnee: [28, 34], fFoot: [38, 86], bKnee: [-26, 34], bFoot: [-42, 86] },
      { hipY: 6, torsoLean: 0.38, headTilt: -0.05, fShoulder: [28, -42], fElbow: [62, -42], fHand: [96, -42], bShoulder: [10, -44], bElbow: [46, -36], bHand: [88, -36], fKnee: [40, 32], fFoot: [52, 86], bKnee: [-28, 36], bFoot: [-50, 86] }
    ],
    super: [
      { hipY: 10, torsoLean: -0.18, headTilt: -0.12, fShoulder: [6, -46], fElbow: [24, -68], fHand: [36, -92], bShoulder: [-14, -46], bElbow: [-32, -62], bHand: [-42, -84], fKnee: [32, 32], fFoot: [44, 86], bKnee: [-30, 34], bFoot: [-46, 86] },
      { hipY: 4, torsoLean: 0.42, headTilt: -0.08, fShoulder: [30, -42], fElbow: [72, -46], fHand: [116, -48], bShoulder: [12, -44], bElbow: [56, -38], bHand: [102, -40], fKnee: [44, 30], fFoot: [58, 86], bKnee: [-32, 34], bFoot: [-56, 86] }
    ],
    hitstun: [
      { hipY: 4, torsoLean: -0.32, headTilt: -0.25, fShoulder: [-8, -44], fElbow: [16, -34], fHand: [32, -52], bShoulder: [-22, -42], bElbow: [-36, -22], bHand: [-46, -36], fKnee: [20, 36], fFoot: [26, 88], bKnee: [-24, 34], bFoot: [-42, 86] }
    ],
    knockdown: [
      { hipY: 66, torsoLean: -1.35, headTilt: -0.2, fShoulder: [-48, -14], fElbow: [-26, -26], fHand: [-10, -18], bShoulder: [-56, -8], bElbow: [-76, 4], bHand: [-92, 12], fKnee: [28, -4], fFoot: [68, 16], bKnee: [18, 12], bFoot: [58, 22] }
    ],
    victory: [
      { hipY: -2, torsoLean: -0.04, headTilt: -0.08, fShoulder: [12, -48], fElbow: [28, -76], fHand: [34, -108], bShoulder: [-14, -48], bElbow: [-28, -26], bHand: [-22, -6], fKnee: [18, 36], fFoot: [26, 88], bKnee: [-18, 36], bFoot: [-28, 88] }
    ]
  };

  function lerp(a, b, t) { return a + (b - a) * t; }
  function lerpPt(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t)]; }

  function blendPose(p1, p2, t) {
    return {
      hipY: lerp(p1.hipY, p2.hipY, t),
      torsoLean: lerp(p1.torsoLean, p2.torsoLean, t),
      headTilt: lerp(p1.headTilt, p2.headTilt, t),
      fShoulder: lerpPt(p1.fShoulder, p2.fShoulder, t),
      fElbow: lerpPt(p1.fElbow, p2.fElbow, t),
      fHand: lerpPt(p1.fHand, p2.fHand, t),
      bShoulder: lerpPt(p1.bShoulder, p2.bShoulder, t),
      bElbow: lerpPt(p1.bElbow, p2.bElbow, t),
      bHand: lerpPt(p1.bHand, p2.bHand, t),
      fKnee: lerpPt(p1.fKnee, p2.fKnee, t),
      fFoot: lerpPt(p1.fFoot, p2.fFoot, t),
      bKnee: lerpPt(p1.bKnee, p2.bKnee, t),
      bFoot: lerpPt(p1.bFoot, p2.bFoot, t)
    };
  }

  function getPoseForFighter(fighter, time) {
    const st = fighter.state;
    if (st === 'attack' && fighter.currentMove) {
      const m = fighter.currentMove;
      const frames = POSES[m.poseKey] || POSES.lp;
      if (frames.length === 1) return frames[0];
      const f = fighter.moveFrame;
      if (f < m.startup) {
        return blendPose(POSES.idle[0], frames[0], Math.min(1, f / Math.max(1, m.startup)));
      } else if (f < m.startup + m.active) {
        return frames[1];
      } else {
        const recT = (f - m.startup - m.active) / Math.max(1, m.recovery);
        return blendPose(frames[1], POSES.idle[0], Math.min(1, recT));
      }
    }
    if (st === 'walkF') {
      const cyc = (time * 9) % 3;
      const i = Math.floor(cyc);
      return blendPose(POSES.walkF[i], POSES.walkF[(i + 1) % 3], cyc - i);
    }
    if (st === 'walkB') {
      const cyc = (time * 7.5) % 2;
      const i = Math.floor(cyc);
      return blendPose(POSES.walkB[i], POSES.walkB[(i + 1) % 2], cyc - i);
    }
    if (st === 'run') {
      const cyc = (time * 13) % 2;
      const i = Math.floor(cyc);
      return blendPose(POSES.run[i], POSES.run[(i + 1) % 2], cyc - i);
    }
    if (st === 'crouch') return POSES.crouch[0];
    if (st === 'jump') return fighter.jumpsUsed > 1 ? POSES.doubleJump[0] : POSES.jump[0];
    if (st === 'block') return POSES.block[0];
    if (st === 'hitstun') return POSES.hitstun[0];
    if (st === 'knockdown' || st === 'ko') return POSES.knockdown[0];
    if (st === 'victory') return POSES.victory[0];

    // Idle breathing
    const breath = 0.5 + 0.5 * Math.sin(time * 4.5 + (fighter.playerIndex * 1.3));
    return blendPose(POSES.idle[0], POSES.idle[1], breath);
  }

  function drawLimb(ctx, x1, y1, x2, y2, w1, w2, fillColor, outlineColor) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len;
    const ny = dx / len;
    ctx.beginPath();
    ctx.moveTo(x1 + nx * w1, y1 + ny * w1);
    ctx.lineTo(x2 + nx * w2, y2 + ny * w2);
    ctx.arc(x2, y2, w2, Math.atan2(ny, nx), Math.atan2(-ny, -nx), false);
    ctx.lineTo(x1 - nx * w1, y1 - ny * w1);
    ctx.arc(x1, y1, w1, Math.atan2(-ny, -nx), Math.atan2(ny, nx), false);
    ctx.closePath();
    ctx.fillStyle = fillColor;
    ctx.fill();
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = 2.6;
    ctx.stroke();
  }

  function renderFighter(ctx, fighter, time, stageRimColor) {
    const cfg = fighter.config;
    const c = cfg.colors;
    const pose = getPoseForFighter(fighter, time);
    const scale = cfg.outfit === 'heavy_armor' ? 1.12 : (cfg.outfit === 'cyber_ninja' ? 0.96 : 1.02);

    ctx.save();
    ctx.translate(fighter.x, fighter.y);

    // Dynamic ground contact shadow
    const airRatio = Math.max(0.25, 1 - Math.abs(fighter.y - fighter.groundY) / 360);
    ctx.save();
    ctx.translate(0, fighter.groundY - fighter.y);
    ctx.fillStyle = `rgba(0, 0, 0, ${0.48 * airRatio})`;
    ctx.beginPath();
    ctx.ellipse(0, 2, 46 * airRatio * scale, 11 * airRatio, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Facing flip & scale
    ctx.scale(fighter.facing * scale, scale);

    // Double-jump front flip spin
    if (fighter.state === 'jump' && fighter.jumpsUsed > 1 && fighter.vy < 180) {
      ctx.translate(0, -90);
      ctx.rotate(time * 16);
      ctx.translate(0, 90);
    }

    // Super aura glow behind character
    if (fighter.energy >= 100 || (fighter.state === 'attack' && fighter.currentMove && (fighter.currentMove.isSuper || fighter.currentMove.isSpecial))) {
      const auraAlpha = fighter.state === 'attack' ? 0.42 : (0.18 + 0.1 * Math.sin(time * 8));
      const ag = ctx.createRadialGradient(0, -88, 12, 0, -88, 108);
      ag.addColorStop(0, c.aura);
      ag.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.save();
      ctx.globalAlpha = auraAlpha;
      ctx.fillStyle = ag;
      ctx.beginPath();
      ctx.arc(0, -88, 108, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Hit flash tint
    const hitFlash = fighter.hitFlashTimer > 0;
    const outline = '#10121c';

    // Translate to hip center
    const hipY = -94 + pose.hipY;
    ctx.translate(0, hipY);

    // Flowing headband / scarf physics
    const wave1 = Math.sin(time * 9 + fighter.x * 0.03) * 10;
    const wave2 = Math.cos(time * 11 + fighter.x * 0.03) * 14;
    const headBaseX = Math.sin(pose.torsoLean) * 62;
    const headBaseY = -Math.cos(pose.torsoLean) * 62 - 14;
    ctx.save();
    ctx.strokeStyle = c.accent;
    ctx.lineWidth = cfg.outfit === 'cyber_ninja' ? 8 : 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(headBaseX - 8, headBaseY);
    ctx.quadraticCurveTo(headBaseX - 34, headBaseY - 4 + wave1, headBaseX - 62, headBaseY + 12 + wave2);
    ctx.stroke();
    ctx.restore();

    // BACK LEG
    drawLimb(ctx, -6, 4, pose.bKnee[0], pose.bKnee[1], 13, 10, hitFlash ? '#ffffff' : c.giShadow, outline);
    drawLimb(ctx, pose.bKnee[0], pose.bKnee[1], pose.bFoot[0], pose.bFoot[1], 10, 8, hitFlash ? '#ffffff' : c.boots, outline);

    // BACK ARM
    drawLimb(ctx, pose.bShoulder[0], pose.bShoulder[1], pose.bElbow[0], pose.bElbow[1], 10, 8.5, hitFlash ? '#ffffff' : c.skinShadow, outline);
    drawLimb(ctx, pose.bElbow[0], pose.bElbow[1], pose.bHand[0], pose.bHand[1], 8.5, 7.5, hitFlash ? '#ffffff' : c.skinShadow, outline);
    // Back fist glove
    ctx.fillStyle = hitFlash ? '#ffffff' : c.accent;
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(pose.bHand[0], pose.bHand[1], 9.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // TORSO
    ctx.save();
    ctx.rotate(pose.torsoLean);
    ctx.beginPath();
    ctx.moveTo(-21, -54);
    ctx.lineTo(23, -54);
    ctx.lineTo(16, 8);
    ctx.lineTo(-16, 8);
    ctx.closePath();
    const torsoGrad = ctx.createLinearGradient(-20, -54, 24, 8);
    torsoGrad.addColorStop(0, hitFlash ? '#ffffff' : c.giShadow);
    torsoGrad.addColorStop(0.55, hitFlash ? '#ffffff' : c.gi);
    torsoGrad.addColorStop(1, hitFlash ? '#ffffff' : c.gi);
    ctx.fillStyle = torsoGrad;
    ctx.fill();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.8;
    ctx.stroke();

    // Outfit details (V-neck karate gi, cyber core, armor chestplate, royal sash)
    if (!hitFlash) {
      if (cfg.outfit === 'karate_gi') {
        ctx.fillStyle = c.skin;
        ctx.beginPath();
        ctx.moveTo(-6, -54);
        ctx.lineTo(10, -54);
        ctx.lineTo(4, -26);
        ctx.closePath();
        ctx.fill();
      } else if (cfg.outfit === 'cyber_ninja') {
        ctx.strokeStyle = c.accent;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-12, -46);
        ctx.lineTo(12, -16);
        ctx.moveTo(12, -46);
        ctx.lineTo(-12, -16);
        ctx.stroke();
      } else if (cfg.outfit === 'heavy_armor') {
        ctx.fillStyle = c.accent;
        ctx.fillRect(-17, -46, 34, 14);
        ctx.strokeRect(-17, -46, 34, 14);
      } else {
        ctx.fillStyle = c.accent;
        ctx.beginPath();
        ctx.moveTo(-18, -50);
        ctx.lineTo(20, -14);
        ctx.lineTo(16, -2);
        ctx.lineTo(-18, -36);
        ctx.closePath();
        ctx.fill();
      }
      // Belt
      ctx.fillStyle = c.belt;
      ctx.fillRect(-18, -4, 36, 11);
      ctx.strokeStyle = outline;
      ctx.lineWidth = 2;
      ctx.strokeRect(-18, -4, 36, 11);
    }

    // HEAD
    ctx.save();
    ctx.translate(2, -70);
    ctx.rotate(pose.headTilt);
    // Face
    ctx.fillStyle = hitFlash ? '#ffffff' : c.skin;
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(0, 0, 15, 17, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // Hair / helmet
    if (!hitFlash) {
      ctx.fillStyle = c.hair;
      ctx.beginPath();
      ctx.moveTo(-16, -4);
      ctx.lineTo(-18, -16);
      ctx.lineTo(-4, -24);
      ctx.lineTo(12, -21);
      ctx.lineTo(19, -10);
      ctx.lineTo(10, -8);
      ctx.lineTo(-4, -10);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // Headband
      ctx.fillStyle = c.accent;
      ctx.fillRect(-15, -10, 30, 6);
      // Determined eye
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(5, -3, 7, 3.5);
      ctx.fillStyle = '#111522';
      ctx.fillRect(8, -3, 3.5, 3.5);
    }
    ctx.restore();
    ctx.restore(); // end torso

    // FRONT LEG
    drawLimb(ctx, 6, 4, pose.fKnee[0], pose.fKnee[1], 14, 11, hitFlash ? '#ffffff' : c.gi, outline);
    drawLimb(ctx, pose.fKnee[0], pose.fKnee[1], pose.fFoot[0], pose.fFoot[1], 11, 8.5, hitFlash ? '#ffffff' : c.boots, outline);

    // FRONT ARM
    drawLimb(ctx, pose.fShoulder[0], pose.fShoulder[1], pose.fElbow[0], pose.fElbow[1], 11, 9, hitFlash ? '#ffffff' : c.skin, outline);
    drawLimb(ctx, pose.fElbow[0], pose.fElbow[1], pose.fHand[0], pose.fHand[1], 9, 8, hitFlash ? '#ffffff' : c.skin, outline);
    // Front fist glove
    ctx.fillStyle = hitFlash ? '#ffffff' : c.accent;
    ctx.strokeStyle = outline;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(pose.fHand[0], pose.fHand[1], 10.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Dynamic attack motion trail / energy glow during active frames
    if (fighter.state === 'attack' && fighter.currentMove) {
      const m = fighter.currentMove;
      if (fighter.moveFrame >= m.startup && fighter.moveFrame < m.startup + m.active + 2) {
        const isKick = m.poseKey === 'lk' || m.poseKey === 'hk';
        const pt = isKick ? pose.fFoot : pose.fHand;
        ctx.save();
        ctx.globalAlpha = 0.78;
        const glowR = m.isSuper ? 44 : (m.isSpecial || m.heavy ? 28 : 18);
        const g = ctx.createRadialGradient(pt[0], pt[1], 3, pt[0], pt[1], glowR);
        g.addColorStop(0, '#ffffff');
        g.addColorStop(0.45, c.aura);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(pt[0], pt[1], glowR, 0, Math.PI * 2);
        ctx.fill();

        // Motion slash arc
        ctx.strokeStyle = m.heavy || m.isSpecial || m.isSuper ? c.aura : '#ffffff';
        ctx.lineWidth = m.isSuper ? 10 : (m.heavy ? 7 : 4);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(pt[0] - 28, pt[1] + 6, 36, -0.9, 0.7);
        ctx.stroke();
        ctx.restore();
      }
    }

    // Block shield barrier visual
    if (fighter.state === 'block') {
      ctx.save();
      ctx.strokeStyle = '#6ce5ff';
      ctx.fillStyle = 'rgba(108, 229, 255, 0.16)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(38, -28, 16, 48, 0, -Math.PI * 0.6, Math.PI * 0.6);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // Stage rim lighting highlight
    if (stageRimColor && !hitFlash) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = stageRimColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(pose.fHand[0], pose.fHand[1], 11, -1.2, 1.2);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }

  // Renders a crisp stylized character portrait into a small canvas (for Select Screen & HUD)
  function renderPortrait(canvas, fighterConfig) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;
    const c = fighterConfig.colors;

    // Dramatic angled background
    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, '#101426');
    bg.addColorStop(1, c.giShadow);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    // Accent diagonal slash
    ctx.fillStyle = c.aura;
    ctx.globalAlpha = 0.28;
    ctx.beginPath();
    ctx.moveTo(w * 0.55, 0);
    ctx.lineTo(w, 0);
    ctx.lineTo(w * 0.45, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;

    ctx.save();
    ctx.translate(w * 0.5, h * 0.66);
    const s = Math.min(w, h) / 110;
    ctx.scale(s, s);

    // Shoulders
    ctx.fillStyle = c.gi;
    ctx.strokeStyle = '#0e111a';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-44, 48);
    ctx.quadraticCurveTo(-34, 6, -14, 2);
    ctx.lineTo(14, 2);
    ctx.quadraticCurveTo(34, 6, 44, 48);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Accent collar / armor trim
    ctx.fillStyle = c.accent;
    ctx.beginPath();
    ctx.moveTo(-16, 4);
    ctx.lineTo(0, 26);
    ctx.lineTo(16, 4);
    ctx.lineTo(10, 4);
    ctx.lineTo(0, 18);
    ctx.lineTo(-10, 4);
    ctx.closePath();
    ctx.fill();

    // Neck & head
    ctx.fillStyle = c.skinShadow;
    ctx.fillRect(-9, -8, 18, 16);
    ctx.fillStyle = c.skin;
    ctx.beginPath();
    ctx.ellipse(0, -24, 22, 26, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Hair
    ctx.fillStyle = c.hair;
    ctx.beginPath();
    ctx.moveTo(-24, -26);
    ctx.lineTo(-28, -46);
    ctx.lineTo(-6, -58);
    ctx.lineTo(18, -52);
    ctx.lineTo(28, -32);
    ctx.lineTo(14, -34);
    ctx.lineTo(-10, -34);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Headband
    ctx.fillStyle = c.accent;
    ctx.fillRect(-23, -36, 46, 9);
    ctx.strokeRect(-23, -36, 46, 9);

    // Fierce eyes
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-13, -23, 10, 4.5);
    ctx.fillRect(4, -23, 10, 4.5);
    ctx.fillStyle = '#111420';
    ctx.fillRect(-9, -23, 4, 4.5);
    ctx.fillRect(7, -23, 4, 4.5);
    // Brows
    ctx.strokeStyle = '#111420';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-15, -27);
    ctx.lineTo(-3, -24);
    ctx.moveTo(16, -27);
    ctx.lineTo(4, -24);
    ctx.stroke();

    ctx.restore();
  }

  IF.renderFighter = renderFighter;
  IF.renderPortrait = renderPortrait;
})(window.IronFang = window.IronFang || {});
