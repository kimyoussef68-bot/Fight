// ai.js - 3-difficulty fighting game CPU opponent (Easy, Medium, Hard) with footsies, blocking, combos, and anti-air
(function (IF) {
  'use strict';

  const DIFFICULTY_PARAMS = {
    easy: {
      reactInterval: 0.34,
      blockChance: 0.25,
      comboChance: 0.2,
      specialChance: 0.14,
      superChance: 0.35,
      antiAirChance: 0.15,
      aggression: 0.45
    },
    medium: {
      reactInterval: 0.18,
      blockChance: 0.56,
      comboChance: 0.55,
      specialChance: 0.32,
      superChance: 0.65,
      antiAirChance: 0.48,
      aggression: 0.68
    },
    hard: {
      reactInterval: 0.08,
      blockChance: 0.82,
      comboChance: 0.85,
      specialChance: 0.5,
      superChance: 0.9,
      antiAirChance: 0.78,
      aggression: 0.86
    }
  };

  class CPUController {
    constructor(difficulty = 'medium') {
      this.setDifficulty(difficulty);
      this.thinkTimer = 0;
      this.currentPlan = 'approach'; // approach, retreat, block, crouch, idle
      this.planTimer = 0;
      this.comboQueue = [];
      this.comboStepDelay = 0;
    }

    setDifficulty(diff) {
      this.difficulty = DIFFICULTY_PARAMS[diff] ? diff : 'medium';
      this.params = DIFFICULTY_PARAMS[this.difficulty];
    }

    getInput(dt, self, opponent, effects) {
      const inp = {
        left: false, right: false, up: false, down: false, run: false,
        jumpPressed: false, lpPressed: false, hpPressed: false,
        lkPressed: false, hkPressed: false, specialPressed: false,
        superPressed: false, block: false
      };

      if (!self || !opponent) return inp;

      const dx = opponent.x - self.x;
      const dist = Math.abs(dx);
      const dirToOpp = dx >= 0 ? 1 : -1;
      const p = this.params;

      // Execute queued combo cancel steps immediately when a hit connects
      if (this.comboQueue.length > 0) {
        this.comboStepDelay -= dt;
        if (self.state === 'attack' && self.moveHasHit && this.comboStepDelay <= 0) {
          const nextMove = this.comboQueue.shift();
          inp[nextMove + 'Pressed'] = true;
          this.comboStepDelay = 0.08;
          return inp;
        }
        if (self.state === 'hitstun' || self.state === 'knockdown' || self.state === 'ko') {
          this.comboQueue.length = 0;
        }
      }

      // Check incoming projectile threat
      let incomingProj = false;
      for (let i = 0; i < effects.projectiles.length; i++) {
        const pr = effects.projectiles[i];
        if (pr.owner !== self && Math.abs(pr.x - self.x) < 220 && Math.sign(pr.vx) === -dirToOpp) {
          incomingProj = true;
          break;
        }
      }

      this.thinkTimer -= dt;
      this.planTimer -= dt;

      if (this.thinkTimer <= 0) {
        this.thinkTimer = p.reactInterval * (0.7 + Math.random() * 0.6);

        // 1. Defend against incoming projectile
        if (incomingProj) {
          if (Math.random() < p.blockChance) {
            this.currentPlan = 'block';
            this.planTimer = 0.28;
          } else if (self.isGrounded() && Math.random() < 0.65) {
            inp.jumpPressed = true;
            this.currentPlan = 'approach';
            this.planTimer = 0.35;
          }
          return inp;
        }

        // 2. React to opponent attacking at close range
        if (opponent.state === 'attack' && dist < 170) {
          if (Math.random() < p.blockChance) {
            this.currentPlan = 'block';
            this.planTimer = 0.3;
            return inp;
          }
        }

        // 3. Anti-air if opponent jumps in close
        if (!opponent.isGrounded() && dist < 155 && Math.random() < p.antiAirChance) {
          if (self.energy >= 25 && Math.random() < 0.5) {
            inp.specialPressed = true;
          } else {
            inp.hpPressed = true;
          }
          return inp;
        }

        // 4. Close range offense & combos
        if (dist < 125) {
          if (self.energy >= 100 && Math.random() < p.superChance * 0.55) {
            inp.superPressed = true;
            return inp;
          }
          if (Math.random() < p.aggression) {
            const roll = Math.random();
            if (roll < 0.35) {
              inp.lpPressed = true;
              if (Math.random() < p.comboChance) {
                this.comboQueue = self.energy >= 25 ? ['hp', 'special'] : ['hp'];
                this.comboStepDelay = 0.04;
              }
            } else if (roll < 0.62) {
              inp.lkPressed = true;
              if (Math.random() < p.comboChance) {
                this.comboQueue = ['hk'];
                this.comboStepDelay = 0.04;
              }
            } else if (roll < 0.82) {
              inp.hpPressed = true;
              if (self.energy >= 100 && Math.random() < p.superChance) {
                this.comboQueue = ['super'];
                this.comboStepDelay = 0.05;
              }
            } else {
              inp.hkPressed = true;
            }
            return inp;
          } else {
            this.currentPlan = Math.random() < 0.5 ? 'block' : 'retreat';
            this.planTimer = 0.25;
          }
        } else if (dist < 280) {
          // Mid-range footsies
          if (self.energy >= 100 && Math.random() < p.superChance * 0.35) {
            inp.superPressed = true;
            return inp;
          }
          if (self.energy >= 25 && Math.random() < p.specialChance) {
            inp.specialPressed = true;
            return inp;
          }
          const roll = Math.random();
          if (roll < p.aggression) {
            this.currentPlan = dist > 195 && Math.random() < 0.55 ? 'run' : 'approach';
            this.planTimer = 0.32;
            if (Math.random() < 0.22 && self.isGrounded()) inp.jumpPressed = true;
          } else if (roll < 0.85) {
            this.currentPlan = 'retreat';
            this.planTimer = 0.24;
          } else {
            this.currentPlan = 'idle';
            this.planTimer = 0.2;
          }
        } else {
          // Far range: throw projectile or rush in
          if (self.energy >= 25 && self.config.specialType === 'projectile' && Math.random() < p.specialChance * 1.2) {
            inp.specialPressed = true;
            return inp;
          }
          this.currentPlan = Math.random() < 0.65 ? 'run' : 'approach';
          this.planTimer = 0.45;
        }
      }

      // Apply continuous movement plan
      if (this.planTimer > 0) {
        if (this.currentPlan === 'block') {
          inp.block = true;
        } else if (this.currentPlan === 'approach') {
          if (dirToOpp > 0) inp.right = true;
          else inp.left = true;
        } else if (this.currentPlan === 'run') {
          if (dirToOpp > 0) inp.right = true;
          else inp.left = true;
          inp.run = true;
        } else if (this.currentPlan === 'retreat') {
          if (dirToOpp > 0) inp.left = true;
          else inp.right = true;
        } else if (this.currentPlan === 'crouch') {
          inp.down = true;
        }
      }

      return inp;
    }
  }

  IF.CPUController = CPUController;
})(window.IronFang = window.IronFang || {});
