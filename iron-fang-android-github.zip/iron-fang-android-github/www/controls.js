// controls.js - Desktop keyboard (P1 & P2) and multi-touch mobile virtual joystick + arcade buttons
(function (IF) {
  'use strict';

  function emptyInput() {
    return {
      left: false, right: false, up: false, down: false, run: false,
      jumpPressed: false, lpPressed: false, hpPressed: false,
      lkPressed: false, hkPressed: false, specialPressed: false,
      superPressed: false, block: false
    };
  }

  class InputManager {
    constructor() {
      this.keys = {};
      this.justPressed = {};
      this.lastTapDir = { p1: { dir: 0, time: 0 }, p2: { dir: 0, time: 0 } };
      this.running = { p1: false, p2: false };

      // Touch state for P1 mobile controls
      this.touchState = {
        left: false, right: false, up: false, down: false, run: false,
        block: false,
        pressed: { jump: false, lp: false, hp: false, lk: false, hk: false, special: false, super: false }
      };
      this.joyTouchId = null;
      this.joyCenter = { x: 0, y: 0 };
      this.prevTouchUp = false;

      this._bindKeyboard();
    }

    _bindKeyboard() {
      const preventKeys = new Set([
        'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'
      ]);

      window.addEventListener('keydown', (e) => {
        if (preventKeys.has(e.code)) e.preventDefault();
        if (!this.keys[e.code]) {
          this.justPressed[e.code] = true;
          this._checkDoubleTap(e.code);
        }
        this.keys[e.code] = true;
      }, { passive: false });

      window.addEventListener('keyup', (e) => {
        this.keys[e.code] = false;
        if (e.code === 'KeyA' || e.code === 'KeyD') this.running.p1 = false;
        if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') this.running.p2 = false;
      });

      window.addEventListener('blur', () => {
        this.keys = {};
        this.justPressed = {};
        this.running.p1 = false;
        this.running.p2 = false;
      });
    }

    _checkDoubleTap(code) {
      const now = performance.now();
      if (code === 'KeyA' || code === 'KeyD') {
        const dir = code === 'KeyD' ? 1 : -1;
        if (this.lastTapDir.p1.dir === dir && now - this.lastTapDir.p1.time < 260) {
          this.running.p1 = true;
        }
        this.lastTapDir.p1 = { dir, time: now };
      } else if (code === 'ArrowLeft' || code === 'ArrowRight') {
        const dir = code === 'ArrowRight' ? 1 : -1;
        if (this.lastTapDir.p2.dir === dir && now - this.lastTapDir.p2.time < 260) {
          this.running.p2 = true;
        }
        this.lastTapDir.p2 = { dir, time: now };
      }
    }

    bindMobileControls(rootEl) {
      if (!rootEl) return;
      const joyZone = rootEl.querySelector('#touch-joystick');
      const joyKnob = rootEl.querySelector('#touch-joy-knob');

      if (joyZone && joyKnob) {
        const updateStick = (clientX, clientY) => {
          const rect = joyZone.getBoundingClientRect();
          const cx = rect.left + rect.width * 0.5;
          const cy = rect.top + rect.height * 0.5;
          const maxR = rect.width * 0.38;
          let dx = clientX - cx;
          let dy = clientY - cy;
          const dist = Math.hypot(dx, dy);
          if (dist > maxR) {
            dx = (dx / dist) * maxR;
            dy = (dy / dist) * maxR;
          }
          joyKnob.style.transform = `translate(${dx}px, ${dy}px)`;

          const normX = dx / maxR;
          const normY = dy / maxR;
          this.touchState.left = normX < -0.28;
          this.touchState.right = normX > 0.28;
          this.touchState.run = Math.abs(normX) > 0.82;
          this.touchState.down = normY > 0.42;
          const isUp = normY < -0.45;
          if (isUp && !this.prevTouchUp) {
            this.touchState.pressed.jump = true;
          }
          this.prevTouchUp = isUp;
          this.touchState.up = isUp;
        };

        const resetStick = () => {
          this.joyTouchId = null;
          joyKnob.style.transform = 'translate(0px, 0px)';
          this.touchState.left = false;
          this.touchState.right = false;
          this.touchState.up = false;
          this.touchState.down = false;
          this.touchState.run = false;
          this.prevTouchUp = false;
        };

        joyZone.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          IF.audio.unlock();
          if (this.joyTouchId === null) {
            this.joyTouchId = e.pointerId;
            try { joyZone.setPointerCapture(e.pointerId); } catch (_) {}
            updateStick(e.clientX, e.clientY);
          }
        }, { passive: false });

        joyZone.addEventListener('pointermove', (e) => {
          if (e.pointerId === this.joyTouchId) {
            e.preventDefault();
            updateStick(e.clientX, e.clientY);
          }
        }, { passive: false });

        const onJoyEnd = (e) => {
          if (e.pointerId === this.joyTouchId) {
            e.preventDefault();
            resetStick();
          }
        };
        joyZone.addEventListener('pointerup', onJoyEnd, { passive: false });
        joyZone.addEventListener('pointercancel', onJoyEnd, { passive: false });
      }

      // Action buttons (multi-touch via pointer events)
      const btns = rootEl.querySelectorAll('[data-action]');
      btns.forEach((btn) => {
        const action = btn.getAttribute('data-action');
        btn.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          IF.audio.unlock();
          btn.classList.add('active');
          if (action === 'block') {
            this.touchState.block = true;
          } else if (action in this.touchState.pressed) {
            this.touchState.pressed[action] = true;
          }
        }, { passive: false });

        const release = (e) => {
          e.preventDefault();
          btn.classList.remove('active');
          if (action === 'block') this.touchState.block = false;
        };
        btn.addEventListener('pointerup', release, { passive: false });
        btn.addEventListener('pointercancel', release, { passive: false });
        btn.addEventListener('pointerleave', release, { passive: false });
      });
    }

    getPlayerInput(playerIndex) {
      const inp = emptyInput();
      if (playerIndex === 0) {
        inp.left = !!(this.keys['KeyA'] || this.touchState.left);
        inp.right = !!(this.keys['KeyD'] || this.touchState.right);
        inp.down = !!(this.keys['KeyS'] || this.touchState.down);
        inp.up = !!(this.keys['KeyW'] || this.touchState.up);
        inp.run = !!(this.running.p1 || this.keys['ShiftLeft'] || this.touchState.run);
        inp.block = !!(this.keys['KeyK'] || this.keys['KeyB'] || this.touchState.block);

        inp.jumpPressed = !!(this.justPressed['KeyW'] || this.touchState.pressed.jump);
        inp.lpPressed = !!(this.justPressed['KeyF'] || this.touchState.pressed.lp);
        inp.hpPressed = !!(this.justPressed['KeyG'] || this.touchState.pressed.hp);
        inp.lkPressed = !!(this.justPressed['KeyH'] || this.touchState.pressed.lk);
        inp.hkPressed = !!(this.justPressed['KeyJ'] || this.touchState.pressed.hk);
        inp.specialPressed = !!(this.justPressed['KeyU'] || this.touchState.pressed.special);
        inp.superPressed = !!(this.justPressed['KeyI'] || this.touchState.pressed.super);
      } else {
        inp.left = !!this.keys['ArrowLeft'];
        inp.right = !!this.keys['ArrowRight'];
        inp.down = !!this.keys['ArrowDown'];
        inp.up = !!this.keys['ArrowUp'];
        inp.run = !!(this.running.p2 || this.keys['ShiftRight']);
        inp.block = !!(this.keys['Numpad0'] || this.keys['Quote']);

        inp.jumpPressed = !!this.justPressed['ArrowUp'];
        inp.lpPressed = !!(this.justPressed['Numpad1'] || this.justPressed['KeyN']);
        inp.hpPressed = !!(this.justPressed['Numpad2'] || this.justPressed['KeyM']);
        inp.lkPressed = !!(this.justPressed['Numpad4'] || this.justPressed['Comma']);
        inp.hkPressed = !!(this.justPressed['Numpad5'] || this.justPressed['Period']);
        inp.specialPressed = !!(this.justPressed['Numpad3'] || this.justPressed['Slash']);
        inp.superPressed = !!(this.justPressed['Numpad6'] || this.justPressed['Semicolon']);
      }
      return inp;
    }

    endFrame() {
      this.justPressed = {};
      const tp = this.touchState.pressed;
      tp.jump = tp.lp = tp.hp = tp.lk = tp.hk = tp.special = tp.super = false;
    }
  }

  IF.InputManager = InputManager;
})(window.IronFang = window.IronFang || {});
