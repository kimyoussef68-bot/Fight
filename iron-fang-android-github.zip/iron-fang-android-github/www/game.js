// game.js - Main 60FPS fighting game engine, rounds, modes (Arcade, Vs CPU, 2P, Training), HUD sync, and attract mode
(function (IF) {
  'use strict';

  const WORLD_W = 1280;
  const WORLD_H = 720;
  const GROUND_Y = 612;
  const ARENA_MIN_X = 76;
  const ARENA_MAX_X = WORLD_W - 76;

  class FightingGame {
    constructor(canvas, uiCallbacks) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.ui = uiCallbacks || {};

      this.input = new IF.InputManager();
      this.effects = new IF.EffectsManager();
      this.cpuP1 = new IF.CPUController('medium'); // Used only in attract mode
      this.cpuP2 = new IF.CPUController('medium');

      this.mode = 'attract'; // attract, arcade, vs_cpu, vs_p2, training
      this.stageId = IF.STAGES[0].id;
      this.p1Id = IF.FIGHTERS[0].id;
      this.p2Id = IF.FIGHTERS[1].id;
      this.arcadeLadder = [];
      this.arcadeIndex = 0;

      this.settings = {
        difficulty: 'medium',
        showHitboxes: false,
        screenShake: true,
        mobileControls: 'auto'
      };

      this.paused = false;
      this.time = 0;
      this.hitstopFrames = 0;
      this.cameraX = 0;

      // Round state
      this.roundNumber = 1;
      this.roundTimer = 99;
      this.phase = 'intro'; // intro, fight, round_over, match_over
      this.phaseTimer = 1.6;
      this.bannerText = '';
      this.bannerSub = '';

      this.p1 = null;
      this.p2 = null;
      this.rafId = null;
      this.lastTs = 0;

      this.startAttractMode();
    }

    startAttractMode() {
      this.mode = 'attract';
      this.paused = false;
      this.stageId = IF.STAGES[0].id;
      this.p1 = new IF.Fighter(0, IF.FIGHTERS[0], 390, GROUND_Y);
      this.p2 = new IF.Fighter(1, IF.FIGHTERS[1], 890, GROUND_Y);
      this.cpuP1.setDifficulty('medium');
      this.cpuP2.setDifficulty('medium');
      this.phase = 'fight';
      this.roundTimer = 99;
      this.bannerText = '';
      this.effects.reset();
    }

    startMatch(opts) {
      this.mode = opts.mode || 'vs_cpu';
      this.p1Id = opts.p1Id || IF.FIGHTERS[0].id;
      this.stageId = opts.stageId || IF.STAGES[0].id;

      if (this.mode === 'arcade') {
        const opponents = IF.FIGHTERS.filter(f => f.id !== this.p1Id).map(f => f.id);
        this.arcadeLadder = opponents;
        this.arcadeIndex = 0;
        this.p2Id = this.arcadeLadder[0];
      } else {
        this.p2Id = opts.p2Id || IF.FIGHTERS[1].id;
      }

      this.cpuP2.setDifficulty(this.settings.difficulty);
      this.paused = false;
      this._initFightersForMatch();
      this.startRound(1);
    }

    advanceArcadeStage() {
      this.arcadeIndex += 1;
      if (this.arcadeIndex >= this.arcadeLadder.length) return false;
      this.p2Id = this.arcadeLadder[this.arcadeIndex];
      this.stageId = IF.STAGES[this.arcadeIndex % IF.STAGES.length].id;
      this._initFightersForMatch();
      this.startRound(1);
      return true;
    }

    _initFightersForMatch() {
      this.p1 = new IF.Fighter(0, IF.getFighterById(this.p1Id), 360, GROUND_Y);
      this.p2 = new IF.Fighter(1, IF.getFighterById(this.p2Id), 920, GROUND_Y);
      this.p1.roundWins = 0;
      this.p2.roundWins = 0;
      if (this.ui.onMatchInit) this.ui.onMatchInit(this.p1, this.p2, this.mode, this.arcadeIndex, this.arcadeLadder.length);
    }

    startRound(num) {
      this.roundNumber = num;
      this.roundTimer = 99;
      this.p1.reset(360, 1);
      this.p2.reset(920, -1);
      if (this.mode === 'training') {
        this.p1.energy = 100;
        this.p2.energy = 100;
        this.phase = 'fight';
        this.bannerText = 'TRAINING';
        this.bannerSub = 'AUTO REGEN • HITBOXES AVAILABLE IN SETTINGS';
        this.phaseTimer = 1.4;
      } else {
        this.phase = 'intro';
        this.phaseTimer = 1.65;
        this.bannerText = `ROUND ${num}`;
        this.bannerSub = this.mode === 'arcade' ? `STAGE ${this.arcadeIndex + 1} OF ${this.arcadeLadder.length}` : 'GET READY';
        IF.audio.playRoundStart();
      }
      this.effects.reset();
    }

    setPaused(val) {
      if (this.mode === 'attract') return;
      this.paused = !!val;
    }

    startLoop() {
      if (this.rafId) window.cancelAnimationFrame(this.rafId);
      this.lastTs = performance.now();
      const tick = (ts) => {
        const rawDt = (ts - this.lastTs) / 1000;
        this.lastTs = ts;
        const dt = Math.min(0.05, Math.max(0.001, rawDt));

        if (!this.paused) {
          this.update(dt);
        }
        this.render();
        this.rafId = window.requestAnimationFrame(tick);
      };
      this.rafId = window.requestAnimationFrame(tick);
    }

    update(dt) {
      this.time += dt;

      // Super freeze dramatic pause
      if (this.effects.superFreezeTimer > 0) {
        this.effects.update(dt, WORLD_W);
        this.input.endFrame();
        return;
      }

      // Hitstop frames for tactile impact
      if (this.hitstopFrames > 0) {
        this.hitstopFrames -= dt * 60;
        this.effects.update(dt * 0.35, WORLD_W);
        this.input.endFrame();
        return;
      }

      // Phase progression
      if (this.phase === 'intro') {
        this.phaseTimer -= dt;
        if (this.phaseTimer <= 0.55) {
          this.bannerText = 'FIGHT!';
          this.bannerSub = '';
        }
        if (this.phaseTimer <= 0) {
          this.phase = 'fight';
          this.bannerText = '';
          this.bannerSub = '';
        }
      } else if (this.phase === 'fight') {
        if (this.mode === 'training' && this.phaseTimer > 0) {
          this.phaseTimer -= dt;
          if (this.phaseTimer <= 0) {
            this.bannerText = '';
            this.bannerSub = '';
          }
        }
        if (this.mode !== 'training' && this.mode !== 'attract') {
          this.roundTimer = Math.max(0, this.roundTimer - dt);
          if (this.roundTimer <= 0) {
            this._finishRound('TIME OVER');
          }
        }
      } else if (this.phase === 'round_over') {
        this.phaseTimer -= dt;
        if (this.phaseTimer <= 0) {
          if (this.p1.roundWins >= 2 || this.p2.roundWins >= 2) {
            this.phase = 'match_over';
            const p1Won = this.p1.roundWins >= 2;
            if (this.ui.onMatchOver) {
              this.ui.onMatchOver({
                p1Won,
                mode: this.mode,
                p1: this.p1,
                p2: this.p2,
                arcadeHasNext: this.mode === 'arcade' && p1Won && this.arcadeIndex + 1 < this.arcadeLadder.length
              });
            }
          } else {
            this.startRound(this.roundNumber + 1);
          }
        }
      }

      const canAct = this.phase === 'fight';

      // Gather inputs
      let in1, in2;
      if (this.mode === 'attract') {
        in1 = this.cpuP1.getInput(dt, this.p1, this.p2, this.effects);
        in2 = this.cpuP2.getInput(dt, this.p2, this.p1, this.effects);
      } else if (this.mode === 'vs_p2') {
        in1 = this.input.getPlayerInput(0);
        in2 = this.input.getPlayerInput(1);
      } else if (this.mode === 'training') {
        in1 = this.input.getPlayerInput(0);
        in2 = { left: false, right: false, up: false, down: false, run: false, jumpPressed: false, lpPressed: false, hpPressed: false, lkPressed: false, hkPressed: false, specialPressed: false, superPressed: false, block: false };
      } else {
        in1 = this.input.getPlayerInput(0);
        in2 = this.cpuP2.getInput(dt, this.p2, this.p1, this.effects);
      }

      this.p1.update(dt, in1, this.p2, this.effects, IF.audio, ARENA_MIN_X, ARENA_MAX_X, canAct);
      this.p2.update(dt, in2, this.p1, this.effects, IF.audio, ARENA_MIN_X, ARENA_MAX_X, canAct);
      IF.resolvePushboxes(this.p1, this.p2, ARENA_MIN_X, ARENA_MAX_X);

      // Combat collision
      if (canAct) {
        const hs = IF.resolveCombat(this.p1, this.p2, this.effects, IF.audio);
        if (hs > 0) this.hitstopFrames = hs;

        // Training auto-regen when idle
        if (this.mode === 'training') {
          if (this.p2.state === 'idle' && this.p2.hp < this.p2.config.maxHp) {
            this.p2.hp = Math.min(this.p2.config.maxHp, this.p2.hp + dt * 420);
          }
          if (this.p1.energy < 100) this.p1.addEnergy(dt * 28);
        } else if (this.mode === 'attract') {
          if (this.p1.hp <= 0 || this.p2.hp <= 0) {
            this.p1.reset(380, 1);
            this.p2.reset(900, -1);
          }
        } else {
          if (this.p1.hp <= 0 || this.p2.hp <= 0) {
            this._finishRound('K.O.');
          }
        }
      }

      // Smooth camera tracking
      const midX = (this.p1.x + this.p2.x) * 0.5 - WORLD_W * 0.5;
      this.cameraX += (midX * 0.45 - this.cameraX) * Math.min(1, dt * 6);

      this.effects.update(dt, WORLD_W);
      this.input.endFrame();

      // Update HUD
      if (this.mode !== 'attract' && this.ui.onHudUpdate) {
        this.ui.onHudUpdate(this.p1, this.p2, Math.ceil(this.roundTimer), this.bannerText, this.bannerSub);
      }
    }

    _finishRound(reason) {
      this.phase = 'round_over';
      this.phaseTimer = 2.3;
      IF.audio.playKO();
      this.effects.addShake(15, 0.4);
      this.effects.addFlash('#ffffff', 0.45);

      const p1Pct = this.p1.hp / this.p1.config.maxHp;
      const p2Pct = this.p2.hp / this.p2.config.maxHp;

      if (p1Pct > p2Pct) {
        this.p1.roundWins += 1;
        this.p1.state = 'victory';
        this.bannerText = p1Pct >= 1 ? 'PERFECT!' : reason;
        this.bannerSub = `${this.p1.config.name} WINS ROUND ${this.roundNumber}`;
      } else if (p2Pct > p1Pct) {
        this.p2.roundWins += 1;
        this.p2.state = 'victory';
        this.bannerText = p2Pct >= 1 ? 'PERFECT!' : reason;
        this.bannerSub = `${this.p2.config.name} WINS ROUND ${this.roundNumber}`;
      } else {
        this.bannerText = 'DOUBLE K.O.';
        this.bannerSub = 'DRAW ROUND';
      }
    }

    render() {
      const ctx = this.ctx;
      const w = WORLD_W;
      const h = WORLD_H;

      ctx.save();
      const shake = this.settings.screenShake ? this.effects.getShakeOffset() : { x: 0, y: 0 };
      ctx.translate(shake.x, shake.y);

      const stage = IF.STAGES.find(s => s.id === this.stageId) || IF.STAGES[0];
      IF.renderStage(ctx, this.stageId, w, h, GROUND_Y, this.time, this.cameraX);

      // Draw fighters (attacker on top)
      const order = this.p1.state === 'attack' ? [this.p2, this.p1] : [this.p1, this.p2];
      for (let i = 0; i < order.length; i++) {
        IF.renderFighter(ctx, order[i], this.time, stage.rimColor);
      }

      // Optional Training/Debug Hitbox & Hurtbox visualizer
      if (this.settings.showHitboxes && this.mode !== 'attract') {
        this._drawDebugBoxes(ctx, this.p1);
        this._drawDebugBoxes(ctx, this.p2);
      }

      this.effects.render(ctx, w, h);
      ctx.restore();
    }

    _drawDebugBoxes(ctx, fighter) {
      const hurt = fighter.getHurtbox();
      ctx.save();
      ctx.strokeStyle = '#00ff88';
      ctx.fillStyle = 'rgba(0, 255, 136, 0.14)';
      ctx.lineWidth = 2;
      ctx.fillRect(hurt.x, hurt.y, hurt.w, hurt.h);
      ctx.strokeRect(hurt.x, hurt.y, hurt.w, hurt.h);

      const hit = IF.getWorldHitbox(fighter);
      if (hit) {
        ctx.strokeStyle = '#ff2a4b';
        ctx.fillStyle = 'rgba(255, 42, 75, 0.28)';
        ctx.fillRect(hit.x, hit.y, hit.w, hit.h);
        ctx.strokeRect(hit.x, hit.y, hit.w, hit.h);
      }
      ctx.restore();
    }
  }

  IF.FightingGame = FightingGame;
})(window.IronFang = window.IronFang || {});
