// audio.js - Pure Web Audio API synthesizer for arcade SFX and dynamic fighting BGM
(function (IF) {
  'use strict';

  class SoundEngine {
    constructor() {
      this.ctx = null;
      this.masterGain = null;
      this.sfxGain = null;
      this.bgmGain = null;
      this.sfxVolume = 0.75;
      this.bgmVolume = 0.45;
      this.muted = false;
      this.bgmPlaying = false;
      this.bgmTimer = null;
      this.bgmStep = 0;
      this.noiseBuffer = null;
    }

    unlock() {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.sfxGain = this.ctx.createGain();
        this.bgmGain = this.ctx.createGain();
        this.sfxGain.connect(this.masterGain);
        this.bgmGain.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);
        this._applyVolumes();
        this._buildNoiseBuffer();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    }

    _buildNoiseBuffer() {
      const sr = this.ctx.sampleRate;
      const len = sr * 0.6;
      const buf = this.ctx.createBuffer(1, len, sr);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBuffer = buf;
    }

    _applyVolumes() {
      if (!this.masterGain) return;
      this.masterGain.gain.value = this.muted ? 0 : 1;
      this.sfxGain.gain.value = this.sfxVolume;
      this.bgmGain.gain.value = this.bgmVolume;
    }

    setSfxVolume(v) {
      this.sfxVolume = Math.max(0, Math.min(1, v));
      this._applyVolumes();
    }

    setBgmVolume(v) {
      this.bgmVolume = Math.max(0, Math.min(1, v));
      this._applyVolumes();
    }

    setMuted(m) {
      this.muted = !!m;
      this._applyVolumes();
    }

    _playNoise(duration, filterFreq, q, gainVal, type = 'bandpass') {
      if (!this.ctx || !this.noiseBuffer || this.muted) return;
      const now = this.ctx.currentTime;
      const src = this.ctx.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = this.ctx.createBiquadFilter();
      filter.type = type;
      filter.frequency.setValueAtTime(filterFreq, now);
      filter.Q.value = q;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(gainVal, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + duration);
      src.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain);
      src.start(now);
      src.stop(now + duration);
    }

    _playTone(freqStart, freqEnd, duration, type, gainVal, delay = 0) {
      if (!this.ctx || this.muted) return;
      const now = this.ctx.currentTime + delay;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freqStart, now);
      if (freqEnd !== freqStart) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), now + duration);
      }
      g.gain.setValueAtTime(gainVal, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + duration);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + duration);
    }

    playWhoosh(heavy) {
      this._playNoise(heavy ? 0.16 : 0.1, heavy ? 520 : 950, 1.4, heavy ? 0.3 : 0.2);
    }

    playHit(heavy) {
      if (heavy) {
        this._playTone(150, 38, 0.22, 'triangle', 0.65);
        this._playTone(280, 60, 0.14, 'sawtooth', 0.3);
        this._playNoise(0.18, 900, 0.8, 0.55, 'lowpass');
      } else {
        this._playTone(220, 70, 0.11, 'triangle', 0.45);
        this._playNoise(0.09, 1400, 1.0, 0.35, 'bandpass');
      }
    }

    playBlock() {
      this._playTone(580, 290, 0.09, 'square', 0.25);
      this._playTone(1120, 740, 0.08, 'triangle', 0.2);
      this._playNoise(0.07, 2400, 2.0, 0.25);
    }

    playJump(isDouble) {
      this._playTone(isDouble ? 280 : 180, isDouble ? 620 : 420, 0.12, 'sine', 0.24);
    }

    playSpecial() {
      this._playTone(220, 880, 0.24, 'sawtooth', 0.28);
      this._playTone(440, 1180, 0.22, 'triangle', 0.24, 0.04);
      this._playNoise(0.25, 1600, 1.2, 0.3);
    }

    playSuper() {
      this._playTone(110, 660, 0.38, 'sawtooth', 0.42);
      this._playTone(220, 1320, 0.42, 'square', 0.25, 0.05);
      this._playTone(80, 35, 0.55, 'triangle', 0.5, 0.1);
      this._playNoise(0.45, 1100, 0.9, 0.42);
    }

    playKO() {
      this._playTone(130, 28, 0.65, 'sawtooth', 0.55);
      this._playTone(90, 24, 0.8, 'triangle', 0.65);
      this._playNoise(0.55, 600, 0.7, 0.5, 'lowpass');
    }

    playRoundStart() {
      this._playTone(330, 330, 0.12, 'square', 0.22, 0);
      this._playTone(440, 440, 0.12, 'square', 0.22, 0.13);
      this._playTone(660, 660, 0.28, 'sawtooth', 0.28, 0.26);
    }

    playMenuSelect() {
      this._playTone(520, 780, 0.07, 'triangle', 0.22);
    }

    playMenuConfirm() {
      this._playTone(440, 660, 0.09, 'square', 0.22, 0);
      this._playTone(660, 990, 0.14, 'square', 0.24, 0.08);
    }

    startBgm() {
      this.unlock();
      if (this.bgmPlaying || !this.ctx) return;
      this.bgmPlaying = true;
      const bassLine = [110, 110, 130.8, 146.8, 110, 110, 164.8, 146.8, 98, 98, 110, 130.8, 146.8, 130.8, 110, 98];
      const leadLine = [440, 0, 523.25, 587.3, 659.25, 0, 587.3, 523.25, 440, 392, 440, 0, 523.25, 659.25, 587.3, 440];
      const stepMs = 155; // ~97 BPM 16th/8th driving arcade groove

      this.bgmTimer = window.setInterval(() => {
        if (!this.bgmPlaying || !this.ctx || this.muted || this.ctx.state !== 'running') return;
        const idx = this.bgmStep % bassLine.length;
        const now = this.ctx.currentTime;

        // Driving synth bass
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();
        bOsc.type = 'sawtooth';
        bOsc.frequency.setValueAtTime(bassLine[idx], now);
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 520;
        bGain.gain.setValueAtTime(0.16, now);
        bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
        bOsc.connect(filter);
        filter.connect(bGain);
        bGain.connect(this.bgmGain);
        bOsc.start(now);
        bOsc.stop(now + 0.14);

        // Kick on beats 0, 4, 8, 12
        if (idx % 4 === 0) {
          const kOsc = this.ctx.createOscillator();
          const kGain = this.ctx.createGain();
          kOsc.type = 'sine';
          kOsc.frequency.setValueAtTime(125, now);
          kOsc.frequency.exponentialRampToValueAtTime(36, now + 0.11);
          kGain.gain.setValueAtTime(0.28, now);
          kGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
          kOsc.connect(kGain);
          kGain.connect(this.bgmGain);
          kOsc.start(now);
          kOsc.stop(now + 0.12);
        }

        // Crisp synth lead on alternate bars
        const leadNote = leadLine[idx];
        if (leadNote > 0 && Math.floor(this.bgmStep / 16) % 2 === 1) {
          const lOsc = this.ctx.createOscillator();
          const lGain = this.ctx.createGain();
          lOsc.type = 'square';
          lOsc.frequency.setValueAtTime(leadNote, now);
          lGain.gain.setValueAtTime(0.06, now);
          lGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
          lOsc.connect(lGain);
          lGain.connect(this.bgmGain);
          lOsc.start(now);
          lOsc.stop(now + 0.13);
        }

        this.bgmStep++;
      }, stepMs);
    }

    stopBgm() {
      this.bgmPlaying = false;
      if (this.bgmTimer) {
        window.clearInterval(this.bgmTimer);
        this.bgmTimer = null;
      }
    }
  }

  IF.audio = new SoundEngine();
})(window.IronFang = window.IronFang || {});
