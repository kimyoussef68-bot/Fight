// main.js - UI controller, arcade menus, character/stage select, HUD synchronization, settings, and bootstrap
(function (IF) {
  'use strict';

  function initApp() {
    const canvas = document.getElementById('game-canvas');
    const stageWrap = document.getElementById('stage-wrap');

    // Screens
    const screens = {
      menu: document.getElementById('screen-menu'),
      select: document.getElementById('screen-select'),
      stage: document.getElementById('screen-stage'),
      hud: document.getElementById('screen-hud'),
      pause: document.getElementById('screen-pause'),
      settings: document.getElementById('screen-settings'),
      result: document.getElementById('screen-result'),
      controlsHelp: document.getElementById('screen-controls')
    };

    // Selection state
    let selectedMode = 'vs_cpu';
    let selectStep = 'p1'; // 'p1' or 'p2'
    let p1Choice = IF.FIGHTERS[0].id;
    let p2Choice = IF.FIGHTERS[1].id;
    let stageChoice = IF.STAGES[0].id;
    let lastActiveScreen = 'menu';
    let lastMatchResult = null;

    // HUD elements
    const hud = {
      p1Name: document.getElementById('hud-p1-name'),
      p2Name: document.getElementById('hud-p2-name'),
      p1Hp: document.getElementById('hud-p1-hp'),
      p1HpDelay: document.getElementById('hud-p1-hp-delay'),
      p2Hp: document.getElementById('hud-p2-hp'),
      p2HpDelay: document.getElementById('hud-p2-hp-delay'),
      p1Energy: document.getElementById('hud-p1-energy'),
      p2Energy: document.getElementById('hud-p2-energy'),
      p1EnergyLabel: document.getElementById('hud-p1-energy-label'),
      p2EnergyLabel: document.getElementById('hud-p2-energy-label'),
      p1Rounds: document.getElementById('hud-p1-rounds'),
      p2Rounds: document.getElementById('hud-p2-rounds'),
      p1Portrait: document.getElementById('hud-p1-portrait'),
      p2Portrait: document.getElementById('hud-p2-portrait'),
      p1Combo: document.getElementById('hud-p1-combo'),
      p2Combo: document.getElementById('hud-p2-combo'),
      timer: document.getElementById('hud-timer'),
      modeBadge: document.getElementById('hud-mode-badge'),
      banner: document.getElementById('hud-banner'),
      bannerMain: document.getElementById('hud-banner-main'),
      bannerSub: document.getElementById('hud-banner-sub'),
      mobileControls: document.getElementById('mobile-controls'),
      superTouchBtn: document.querySelector('[data-action="super"]')
    };

    // Instantiate game engine
    const game = new IF.FightingGame(canvas, {
      onMatchInit(p1, p2, mode, arcadeIdx, arcadeLen) {
        hud.p1Name.textContent = p1.config.name;
        hud.p2Name.textContent = mode === 'vs_p2' ? p2.config.name : `${p2.config.name} (CPU)`;
        IF.renderPortrait(hud.p1Portrait, p1.config);
        IF.renderPortrait(hud.p2Portrait, p2.config);
        const labels = {
          arcade: `ARCADE ${arcadeIdx + 1}/${arcadeLen}`,
          vs_cpu: `VS CPU • ${game.settings.difficulty.toUpperCase()}`,
          vs_p2: 'LOCAL 2P',
          training: 'TRAINING'
        };
        hud.modeBadge.textContent = labels[mode] || 'FIGHT';
      },
      onHudUpdate(p1, p2, timerSec, bannerText, bannerSub) {
        const p1Pct = Math.max(0, (p1.hp / p1.config.maxHp) * 100);
        const p1Del = Math.max(0, (p1.displayHp / p1.config.maxHp) * 100);
        const p2Pct = Math.max(0, (p2.hp / p2.config.maxHp) * 100);
        const p2Del = Math.max(0, (p2.displayHp / p2.config.maxHp) * 100);

        hud.p1Hp.style.width = `${p1Pct}%`;
        hud.p1HpDelay.style.width = `${p1Del}%`;
        hud.p2Hp.style.width = `${p2Pct}%`;
        hud.p2HpDelay.style.width = `${p2Del}%`;

        hud.p1Energy.style.width = `${p1.energy}%`;
        hud.p2Energy.style.width = `${p2.energy}%`;
        hud.p1Energy.classList.toggle('max-ready', p1.energy >= 100);
        hud.p2Energy.classList.toggle('max-ready', p2.energy >= 100);
        hud.p1EnergyLabel.textContent = p1.energy >= 100 ? 'MAX SUPER!' : `${Math.floor(p1.energy)}%`;
        hud.p2EnergyLabel.textContent = p2.energy >= 100 ? 'MAX SUPER!' : `${Math.floor(p2.energy)}%`;

        if (hud.superTouchBtn) {
          hud.superTouchBtn.classList.toggle('super-ready', p1.energy >= 100);
        }

        // Round orbs
        hud.p1Rounds.innerHTML = `<span class="orb ${p1.roundWins >= 1 ? 'won' : ''}"></span><span class="orb ${p1.roundWins >= 2 ? 'won' : ''}"></span>`;
        hud.p2Rounds.innerHTML = `<span class="orb ${p2.roundWins >= 1 ? 'won' : ''}"></span><span class="orb ${p2.roundWins >= 2 ? 'won' : ''}"></span>`;

        hud.timer.textContent = game.mode === 'training' ? '∞' : String(timerSec).padStart(2, '0');

        // Combos
        if (p1.comboCount >= 2) {
          hud.p1Combo.classList.add('visible');
          hud.p1Combo.querySelector('.combo-num').textContent = `${p1.comboCount} HIT`;
        } else {
          hud.p1Combo.classList.remove('visible');
        }
        if (p2.comboCount >= 2) {
          hud.p2Combo.classList.add('visible');
          hud.p2Combo.querySelector('.combo-num').textContent = `${p2.comboCount} HIT`;
        } else {
          hud.p2Combo.classList.remove('visible');
        }

        // Center Banner
        if (bannerText) {
          hud.banner.classList.add('visible');
          hud.bannerMain.textContent = bannerText;
          hud.bannerSub.textContent = bannerSub || '';
        } else {
          hud.banner.classList.remove('visible');
        }
      },
      onMatchOver(result) {
        lastMatchResult = result;
        const titleEl = document.getElementById('result-title');
        const subEl = document.getElementById('result-sub');
        const nextBtn = document.getElementById('btn-result-next');

        if (result.mode === 'vs_p2') {
          titleEl.textContent = result.p1Won ? `${result.p1.config.name} WINS!` : `${result.p2.config.name} WINS!`;
          subEl.textContent = `FINAL SCORE ${result.p1.roundWins} - ${result.p2.roundWins}`;
          nextBtn.style.display = 'none';
        } else if (result.p1Won) {
          if (result.mode === 'arcade' && !result.arcadeHasNext) {
            titleEl.textContent = 'ARCADE CHAMPION!';
            subEl.textContent = `${result.p1.config.name} CONQUERED ALL CHALLENGERS`;
            nextBtn.style.display = 'none';
          } else if (result.arcadeHasNext) {
            titleEl.textContent = 'STAGE CLEAR!';
            subEl.textContent = `NEXT CHALLENGER AWAITS`;
            nextBtn.style.display = 'inline-flex';
          } else {
            titleEl.textContent = 'VICTORY!';
            subEl.textContent = `${result.p1.config.name} DEFEATED ${result.p2.config.name}`;
            nextBtn.style.display = 'none';
          }
        } else {
          titleEl.textContent = 'DEFEAT';
          subEl.textContent = `${result.p2.config.name} CLAIMED THE CROWN`;
          nextBtn.style.display = 'none';
        }
        showScreen('result');
      }
    });

    // Bind mobile touch controls
    game.input.bindMobileControls(hud.mobileControls);

    function updateMobileControlsVisibility() {
      const mode = game.settings.mobileControls;
      const isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || window.innerWidth <= 920;
      const show = mode === 'on' || (mode === 'auto' && isTouch);
      hud.mobileControls.classList.toggle('hidden', !show);
    }

    function showScreen(name) {
      Object.keys(screens).forEach((k) => {
        if (screens[k]) screens[k].classList.toggle('active', k === name);
      });
      if (name === 'hud') {
        lastActiveScreen = 'hud';
        updateMobileControlsVisibility();
      } else if (name === 'menu') {
        lastActiveScreen = 'menu';
      }
    }

    // Build Character Select Grid
    const rosterGrid = document.getElementById('roster-grid');
    const selectStepLabel = document.getElementById('select-step-label');
    const previewP1Canvas = document.getElementById('preview-p1-canvas');
    const previewP2Canvas = document.getElementById('preview-p2-canvas');
    const previewP1Info = document.getElementById('preview-p1-info');
    const previewP2Info = document.getElementById('preview-p2-info');

    function renderSelectPreviews() {
      const f1 = IF.getFighterById(p1Choice);
      const f2 = IF.getFighterById(p2Choice);
      IF.renderPortrait(previewP1Canvas, f1);
      IF.renderPortrait(previewP2Canvas, f2);
      previewP1Info.innerHTML = `
        <div class="fighter-name">${f1.name}</div>
        <div class="fighter-title">${f1.title} • ${f1.style}</div>
        <div class="stat-bars">
          <div><span>PWR</span><i style="width:${f1.stats.power}%"></i></div>
          <div><span>SPD</span><i style="width:${f1.stats.speed}%"></i></div>
          <div><span>DEF</span><i style="width:${f1.stats.defense}%"></i></div>
        </div>
        <div class="move-tags"><span>SP: ${f1.specialName}</span><span>MAX: ${f1.superName}</span></div>
      `;
      previewP2Info.innerHTML = `
        <div class="fighter-name">${f2.name}</div>
        <div class="fighter-title">${f2.title} • ${f2.style}</div>
        <div class="stat-bars">
          <div><span>PWR</span><i style="width:${f2.stats.power}%"></i></div>
          <div><span>SPD</span><i style="width:${f2.stats.speed}%"></i></div>
          <div><span>DEF</span><i style="width:${f2.stats.defense}%"></i></div>
        </div>
        <div class="move-tags"><span>SP: ${f2.specialName}</span><span>MAX: ${f2.superName}</span></div>
      `;

      selectStepLabel.textContent = selectStep === 'p1'
        ? 'SELECT PLAYER 1 FIGHTER'
        : (selectedMode === 'vs_p2' ? 'SELECT PLAYER 2 FIGHTER' : 'SELECT CPU OPPONENT');

      rosterGrid.querySelectorAll('.roster-card').forEach((card) => {
        const id = card.getAttribute('data-id');
        card.classList.toggle('is-p1', id === p1Choice);
        card.classList.toggle('is-p2', id === p2Choice && selectedMode !== 'arcade');
      });
    }

    function buildRoster() {
      rosterGrid.innerHTML = '';
      IF.FIGHTERS.forEach((f) => {
        const card = document.createElement('button');
        card.type = 'button';
        card.className = 'roster-card';
        card.setAttribute('data-id', f.id);
        card.innerHTML = `
          <canvas width="140" height="140"></canvas>
          <div class="roster-card-name">${f.name}</div>
          <div class="roster-card-sub">${f.title}</div>
          <span class="tag-p1">P1</span>
          <span class="tag-p2">P2</span>
        `;
        IF.renderPortrait(card.querySelector('canvas'), f);
        card.addEventListener('click', () => {
          IF.audio.unlock();
          IF.audio.playMenuSelect();
          if (selectStep === 'p1') {
            p1Choice = f.id;
            if (p2Choice === p1Choice) {
              const other = IF.FIGHTERS.find(x => x.id !== p1Choice);
              if (other) p2Choice = other.id;
            }
          } else {
            p2Choice = f.id;
          }
          renderSelectPreviews();
        });
        rosterGrid.appendChild(card);
      });
    }

    // Build Stage Select Grid
    const stageGrid = document.getElementById('stage-grid');
    function buildStageSelect() {
      stageGrid.innerHTML = '';
      IF.STAGES.forEach((st) => {
        const card = document.createElement('button');
        card.type = 'button';
        card.className = 'stage-card' + (st.id === stageChoice ? ' selected' : '');
        card.setAttribute('data-stage', st.id);
        card.innerHTML = `
          <canvas width="320" height="180"></canvas>
          <div class="stage-card-info">
            <div class="stage-card-name">${st.name}</div>
            <div class="stage-card-sub">${st.subtitle}</div>
          </div>
        `;
        const sCanvas = card.querySelector('canvas');
        const sCtx = sCanvas.getContext('2d');
        sCtx.save();
        sCtx.scale(320 / 1280, 180 / 720);
        IF.renderStage(sCtx, st.id, 1280, 720, 612, 2.5, 0);
        sCtx.restore();

        card.addEventListener('click', () => {
          IF.audio.unlock();
          IF.audio.playMenuSelect();
          stageChoice = st.id;
          stageGrid.querySelectorAll('.stage-card').forEach(c => c.classList.toggle('selected', c.getAttribute('data-stage') === stageChoice));
        });
        stageGrid.appendChild(card);
      });
    }

    buildRoster();
    buildStageSelect();
    renderSelectPreviews();

    // Main Menu buttons
    document.querySelectorAll('[data-mode]').forEach((btn) => {
      btn.addEventListener('click', () => {
        IF.audio.unlock();
        IF.audio.startBgm();
        IF.audio.playMenuConfirm();
        selectedMode = btn.getAttribute('data-mode');
        selectStep = 'p1';
        renderSelectPreviews();
        showScreen('select');
      });
    });

    // Quick Fight button (jumps right into action immediately!)
    document.getElementById('btn-quick-fight').addEventListener('click', () => {
      IF.audio.unlock();
      IF.audio.startBgm();
      IF.audio.playMenuConfirm();
      selectedMode = 'vs_cpu';
      game.startMatch({ mode: 'vs_cpu', p1Id: p1Choice, p2Id: p2Choice, stageId: stageChoice });
      showScreen('hud');
    });

    // Character Select confirm / back
    document.getElementById('btn-select-confirm').addEventListener('click', () => {
      IF.audio.unlock();
      IF.audio.playMenuConfirm();
      if (selectedMode === 'arcade') {
        game.startMatch({ mode: 'arcade', p1Id: p1Choice, stageId: IF.STAGES[0].id });
        showScreen('hud');
        return;
      }
      if (selectStep === 'p1') {
        selectStep = 'p2';
        renderSelectPreviews();
      } else {
        showScreen('stage');
      }
    });

    document.getElementById('btn-select-back').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      if (selectStep === 'p2') {
        selectStep = 'p1';
        renderSelectPreviews();
      } else {
        showScreen('menu');
      }
    });

    // Stage Select confirm / back
    document.getElementById('btn-stage-fight').addEventListener('click', () => {
      IF.audio.unlock();
      IF.audio.startBgm();
      IF.audio.playMenuConfirm();
      game.startMatch({ mode: selectedMode, p1Id: p1Choice, p2Id: p2Choice, stageId: stageChoice });
      showScreen('hud');
    });

    document.getElementById('btn-stage-back').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      showScreen('select');
    });

    // HUD top quick buttons
    document.getElementById('btn-hud-pause').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      game.setPaused(true);
      showScreen('pause');
    });

    const muteBtn = document.getElementById('btn-hud-mute');
    muteBtn.addEventListener('click', () => {
      IF.audio.unlock();
      IF.audio.setMuted(!IF.audio.muted);
      muteBtn.textContent = IF.audio.muted ? '🔇' : '🔊';
    });

    // Pause menu buttons
    document.getElementById('btn-pause-resume').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      game.setPaused(false);
      showScreen('hud');
    });
    document.getElementById('btn-pause-restart').addEventListener('click', () => {
      IF.audio.playMenuConfirm();
      game.startMatch({ mode: selectedMode, p1Id: p1Choice, p2Id: p2Choice, stageId: stageChoice });
      showScreen('hud');
    });
    document.getElementById('btn-pause-settings').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      showScreen('settings');
    });
    document.getElementById('btn-pause-menu').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      game.startAttractMode();
      showScreen('menu');
    });

    // Settings & Controls modals
    document.getElementById('btn-open-settings').addEventListener('click', () => {
      IF.audio.unlock();
      IF.audio.playMenuSelect();
      showScreen('settings');
    });
    document.getElementById('btn-open-controls').addEventListener('click', () => {
      IF.audio.unlock();
      IF.audio.playMenuSelect();
      showScreen('controlsHelp');
    });
    document.getElementById('btn-controls-close').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      showScreen(lastActiveScreen);
    });
    document.getElementById('btn-settings-close').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      if (lastActiveScreen === 'hud') {
        showScreen('pause');
      } else {
        showScreen('menu');
      }
    });

    // Settings inputs
    const selDiff = document.getElementById('set-difficulty');
    const rngSfx = document.getElementById('set-sfx');
    const rngBgm = document.getElementById('set-bgm');
    const selMobile = document.getElementById('set-mobile');
    const chkHitbox = document.getElementById('set-hitboxes');
    const chkShake = document.getElementById('set-shake');

    selDiff.addEventListener('change', () => {
      game.settings.difficulty = selDiff.value;
      game.cpuP2.setDifficulty(selDiff.value);
    });
    rngSfx.addEventListener('input', () => IF.audio.setSfxVolume(Number(rngSfx.value) / 100));
    rngBgm.addEventListener('input', () => IF.audio.setBgmVolume(Number(rngBgm.value) / 100));
    selMobile.addEventListener('change', () => {
      game.settings.mobileControls = selMobile.value;
      updateMobileControlsVisibility();
    });
    chkHitbox.addEventListener('change', () => { game.settings.showHitboxes = chkHitbox.checked; });
    chkShake.addEventListener('change', () => { game.settings.screenShake = chkShake.checked; });

    // Result screen buttons
    document.getElementById('btn-result-next').addEventListener('click', () => {
      IF.audio.playMenuConfirm();
      if (game.advanceArcadeStage()) {
        showScreen('hud');
      } else {
        game.startAttractMode();
        showScreen('menu');
      }
    });
    document.getElementById('btn-result-rematch').addEventListener('click', () => {
      IF.audio.playMenuConfirm();
      game.startMatch({ mode: selectedMode, p1Id: p1Choice, p2Id: p2Choice, stageId: stageChoice });
      showScreen('hud');
    });
    document.getElementById('btn-result-menu').addEventListener('click', () => {
      IF.audio.playMenuSelect();
      game.startAttractMode();
      showScreen('menu');
    });

    // Keyboard Escape to toggle Pause
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Escape' && game.mode !== 'attract') {
        if (screens.hud.classList.contains('active')) {
          game.setPaused(true);
          showScreen('pause');
        } else if (screens.pause.classList.contains('active')) {
          game.setPaused(false);
          showScreen('hud');
        }
      }
    });

    // Responsive resize handling
    function handleResize() {
      updateMobileControlsVisibility();
      if (stageWrap) {
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        stageWrap.style.width = vw + 'px';
        stageWrap.style.height = vh + 'px';
      }
    }
    window.addEventListener('resize', handleResize);
    handleResize();

    showScreen('menu');
    game.startLoop();
  }

  window.addEventListener('load', initApp);
})(window.IronFang = window.IronFang || {});
